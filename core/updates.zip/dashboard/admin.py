from django.contrib import admin

# Register your models here.
# SEO models are already registered in app/admin.py
